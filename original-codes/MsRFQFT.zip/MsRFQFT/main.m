clc,clear,close all,warning off
addpath('.\main_functions\')

img_id = 14; %% 14, 24, 32, 5
[data, map] = ReadData(num2str(img_id));

method = "MfRFQFT"; %% RFFT, MsRFQFT, MfRFQFT

switch method
    case "RFFT"
        sigma = SetPara(img_id);
        result = RFFT(data,sigma);
    case "MsRFQFT"
        sigma = SetPara_MS(img_id);
        result = MsRFQFT(data,sigma);
    case "MfRFQFT"
        sigma = SetPara_MF(img_id);
        result = MfRFQFT(data,sigma);
end

%% Result evaluation
figure,imshow(result)
[auc_pdpf,auc_pdtau,auc_pftau,PD,PF] =  AUCall(result,map);
auc = [auc_pdpf,auc_pdtau,auc_pftau]'