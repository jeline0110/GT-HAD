% Read me and Copyright
%
% The code can only be used for academic purposes and the
% following paper must be cited.
% 
%
% B. Rasti, M. O. Ulfarsson, and  J. R. Sveinsson, �Hyperspectral Feature Extraction Using Total Variation Component Analysis�, 
% IEEE Trans. Geoscience and Remote Sensing, 54 (12), 6976-6985.