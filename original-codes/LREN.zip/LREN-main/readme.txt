LREN

This is the code for LREN

Usage: run"python run_main_LREN.py"