Low rank representation
