abu-beach-4 <---> Pavia

abu-urban-2 <---> Coast

HYDICE_data <---> Hydice

sandiego_plane <---> SanDiego
